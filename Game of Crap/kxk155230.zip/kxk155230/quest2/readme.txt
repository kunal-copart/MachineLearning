To plot the chart for part b, we need to executed
plot.R